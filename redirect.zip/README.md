# Starter

Starter is the simplest possible hook: it just accepts all transactions and logs that it is running.

to test:
- in the develop pane, compile starter.c
- in the deploy pane, deploy it to Alice account
- set up payment transaction from Alice to Bob
- run it and see in the debug stream 'Accept.c: Called.'

Modifying the tracing message and compiling with different optimizations are left as an exercise for the reader.
